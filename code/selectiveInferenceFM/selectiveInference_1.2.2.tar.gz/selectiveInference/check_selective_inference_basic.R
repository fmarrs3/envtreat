set.seed(43)
n = 50
p = 10
sigma = 1
xu = matrix(rnorm(n*p),n,p)
xu <- sweep(xu, 2, 1:p, "*")    # X with some interesting mean and variance
xu <- sweep(xu, 2, (1:p)*2, "+")
xs=scale(xu,TRUE,TRUE)
sdx <- apply(xu,2,sd)
mx <- apply(xu,2,mean)


beta0 = c(3,2,rep(0,p-2))
y = xu%*%beta0 + sigma*rnorm(n)
y=1*(y>mean(y))

# As coded in fixedLassoInf example
gfit = glmnet(xs,y,standardize=FALSE, family="binomial")
lambda = .8
betas = coef(gfit, s=lambda/n, exact=TRUE)
outs = fixedLassoInf(xs,y,betas,lambda, family="binomial",alpha=.05)

# As coded in fixedLassoInf example but unscaled X
gfit = glmnet(xu,y,standardize=TRUE, family="binomial")
betau = coef(gfit, s=lambda/n, exact=TRUE)
outu = fixedLassoInf(xu,y,betau,lambda, family="binomial",alpha=.05)

cbind(outs$pv, outu$pv)   # close to same, same conclusion, shouldn't be enough to break things I don't think.
sum(abs(betas)) / sum(abs(betau))
mean(sdx)





# CV:  check if cross-validated betas seems to work
gfit = cv.glmnet(xs,y,standardize=TRUE, family="binomial")
lambda = gfit$lambda.1se
beta = coef(gfit, s=lambda/n, exact=TRUE)
out2 = fixedLassoInf(xs,y,beta,lambda,family="binomial",alpha=.05)
# out2$pv - outs$pv   # betas are very different!


# n*lambda and coef direct from fit without EXACT=TRUE
gfit = cv.glmnet(xs,y,standardize=FALSE, family="binomial")
lambda3 = gfit$lambda.1se
beta3 = coef(gfit)  #, s=lambda, exact=TRUE)
out3 = fixedLassoInf(xs,y,beta3,lambda3*n, family="binomial",alpha=.05)
out3$pv
outs$pv

pv3_all <- rep(NA, length(beta3))
pv3_all[which(beta3[-1]!=0) + 1] <- out3$pv

# Scaling
gfit = cv.glmnet(xu,y,standardize=TRUE, family="binomial")
lambda4 = gfit$lambda.1se
beta4 = coef(gfit) #, s=lambda, exact=TRUE)
beta_scale <- beta4[-1]*sdx 
beta_scale <- c(beta4[1] + sum(beta4[-1]*mx), beta_scale)
delta <- sum(abs(beta_scale))/sum(abs(beta4))
delta

out4 = fixedLassoInf(xu,y,beta4,lambda4*n, family="binomial",alpha=.05)
pv4_all <- rep(NA, length(beta4))
pv4_all[which(beta4[-1]!=0) + 1] <- out4$pv

cbind(beta3, pv3_all, beta4, pv4_all)

lambda3
lambda4

# Scaling with same lambda3
beta5 = coef(gfit, s=lambda3, exact=TRUE) #, s=lambda, exact=TRUE)
beta_scale <- beta5[-1]*sdx 
beta_scale <- c(beta5[1] + sum(beta5[-1]*mx), beta_scale)
delta5 <- sum(abs(beta_scale))/sum(abs(beta5))
delta5

out5 = fixedLassoInf(xu,y,beta5,lambda3*n, family="binomial",alpha=.05)
pv5_all <- rep(NA, length(beta5))
pv5_all[which(beta5[-1]!=0) + 1] <- out5$pv

cbind(beta3, pv3_all, beta5, pv5_all, beta4, pv4_all)

# The first two columns of p-values should be nearly the same, and they are. I think everything should work alright. 
# Still want to do simulation studies
