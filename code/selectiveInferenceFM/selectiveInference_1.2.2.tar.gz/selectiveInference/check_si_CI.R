# Test selective inference coverages
# 4/13/17
#

rm(list=ls())

#### Run this block to test original package
# remove.packages("selectiveInference", lib= "~/Desktop/selectiveInference_1.2.4_FM")
# install.packages("~/Dropbox/BiTEN/selectiveInferenceFM", repos = NULL, type="source", lib = "~/Dropbox/BiTEN/selectiveInferenceFM")
# library("selectiveInference", lib.loc = "~/Dropbox/BiTEN/selectiveInferenceFM")
# writedir <- "~/Dropbox/BiTEN/check_selectiveInference_1.2.2"
####


#### Run this block to test Frank's modifications
remove.packages("selectiveInference", lib = "~/Dropbox/BiTEN/selectiveInferenceFM")
install.packages("~/Desktop/selectiveInference_1.2.4_FM", repos = NULL, type="source", lib = "~/Desktop/selectiveInference_1.2.4_FM")
library("selectiveInference", lib.loc = "~/Desktop/selectiveInference_1.2.4_FM")
writedir <- "~/Dropbox/BiTEN/check_selectiveInference_1.2.4"
####


####
# setwd("~/Dropbox/BiTEN/selectiveInferenceFM")
seed <- 43
scaleX <- T
####


#### Inputs
n <- 1000
p <- 50
ne <- 1e3   # number of errors
mu <- 1     # X mean
sigma <- 2  # X sd
rho <- .5   # correlation in X
####


#### Build X and beta
dir.create(writedir, showWarnings = F)

set.seed(seed)
X <- matrix(rnorm(n*(p-1)),n,p-1)
# X <- matrix(NA, n, p-1)
# X[,1] <- rnorm(n, mu, sigma)
# rho <- .5  # autocorrelated
# for(j in 2:ncol(X)){
#   X[,j] <- rho*X[,j-1] + (1-rho)*rnorm(n, mu, sigma)
# }
if(scaleX){
  X <- scale(X,T,T)
}
X <- cbind(1, X)   # with intercept

# beta0 <- rep(0,p)
# beta0[1] <- -55
# beta0[2:6] <- 10
# beta0[7:11] <- 1
# beta0[12:21] <- .1
beta0 = c(0,8,4,2,1,rep(0,p-5))

Xb <- X %*% beta0
####



#### Run sims
inci <- pvs <- sig_ci <- beta_nonzero <- est_inci <- matrix(NA, p-1, ne)   # fraction of times true coefficient in CI

# inci[1,] <- 1
# pvs[1,] <- 0
# sig_ci[1,] <- 1
# beta_nonzero[1,] <- 1

for(i in 1:ne){
  set.seed(i)
  eps <- rnorm(n)
  Y <- Xb + eps
  Y <- 1*(c(Y)>0)
  if(all(Y==1)){Y[length(Y)] <- 0}
  if(all(Y==0)){Y[length(Y)] <- 1}
  
  # Fit lasso choosing lambda by CV and min mean AUC, minus 1 to deal with intercept
  cv <- cv.glmnet(x=X[,-1], y=Y, family="binomial", type.measure = "auc", standardize=!scaleX)   # thresh?   
  beta <- coef(cv)   # minimum mean AUC default choice
  lambda <- cv$lambda.1se   # lambda chosen
  
  nonzeros <- which(beta[-1] != 0) 
  out <- fixedLassoInf(x=X[,-1], y=Y, beta=beta, lambda=lambda*n, family="binomial", alpha=.05, tol.beta=1e-9)
  
  beta_nonzero[nonzeros, i] <- 1
  beta_nonzero[-nonzeros, i] <- 0
  
  inci[nonzeros, i] <- 1*(out$ci[,1] < beta0[-1][nonzeros] & out$ci[,2] > beta0[-1][nonzeros])  # true coeff in CIs?
  # inci[-1,][-nonzeros, i] <- 1*(beta0[-1][-nonzeros]==0)  # true coeff estimated zero and is actually zero
  
  sig_ci[nonzeros, i] <- 1*!(out$ci[,1] < 0 & out$ci[,2] > 0)  # signif nonzero?
  # sig_ci[-nonzeros, i] <- 0  # 1*(beta0[-nonzeros]==0)  # true coeff estimated zero and is actually zero
  
  pvs[nonzeros, i] <- out$pv
  # pvs[-nonzeros, i] <- 
  
  est_inci[nonzeros, i] <- 1*(out$ci[,1] < beta[-1][nonzeros] & out$ci[,2] > beta[-1][nonzeros])
    
  
  if(i %% 100 == 0){cat(i, "; \t")}
}
####

apply(beta_nonzero,1,mean, na.rm=T)
apply(inci,1,mean, na.rm=T)



truezero <- which(beta0[-1] == 0)
empa <- mean(pvs[truezero,] < .05, na.rm=T)
ninf <- sum(beta_nonzero[truezero,])   # number of opportunities for inference

nonzeroest <- which(beta_nonzero == 1, arr.ind=T)
delta <- 1*(pvs < .05) != sig_ci
# itest <- nonzeroest[ !(nonzeroest[,1] %in% truezero), ]
disagfrac <- mean(delta[nonzeroest], na.rm=T)
ndisag <- nrow(nonzeroest)

powerci <- apply(sig_ci[-truezero,],1,mean, na.rm=T)
powerp <- apply(pvs[-truezero,],1,function(z) mean(z < .05, na.rm=T))


estin <- mean(est_inci[sig_ci == 1], na.rm=T)

outfile <- data.frame( cbind(empa, ninf, disagfrac, ndisag, estin, powerp, powerci, beta0[-1][1:length(powerp)]))


names(outfile) <- c("emp_alpha", "nalpha", "disag_frac", "ndisag",  "frac_estinci", "power_p", "power_ci", "beta0")

outdir <- file.path(writedir, paste0("sicheck_nominal_n",n,"_p",p,"_scale", as.numeric(scaleX),"_seed",seed,"_lambdaCV"))
dir.create(outdir, showWarnings=F)
write.table(inci, file=file.path(outdir, paste0("inci.txt")), row.names=F, col.names=F)
write.table(sig_ci, file=file.path(outdir, "sig_ci.txt"), row.names=F, col.names=F)
write.table(pvs, file=file.path(outdir, "pvs.txt"), row.names=F, col.names=F)
write.table(beta_nonzero, file=file.path(outdir, "beta_nonzero.txt"), row.names=F, col.names=F)
write.table(est_inci, file=file.path(outdir, "est_inci.txt"), row.names=F, col.names=F)
write.table(outfile, file=file.path(outdir, "summary.txt"), row.names=F, col.names=F)
####




####################
####  Unscaled  ####
####################

####
# setwd("~/Dropbox/BiTEN/selectiveInferenceFM")
seed <- 43
scaleX <- F
####


#### Inputs
n <- 100
p <- 50
ne <- 1e3   # number of errors
mu <- 1     # X mean
sigma <- 2  # X sd
rho <- .5   # correlation in X
####

#### Build X and beta
dir.create(writedir, showWarnings = F)

set.seed(seed)
phalf <- floor((p-1)/2)
# X <- matrix(rnorm(n*(phalf)),n,phalf)
# X <- cbind(X, matrix(sample(c(0,1), (p-1-phalf)*n, replace=T, prob=c(.75,.25)), n, p-1-phalf  ))

X <- matrix(sample(c(0,1), (p-1)*n, replace=T, prob=c(.75,.25)), n, p-1  )

dim(X)

# X <- matrix(NA, n, p-1)
# X[,1] <- rnorm(n, mu, sigma)
# rho <- .5  # autocorrelated
# for(j in 2:ncol(X)){
#   X[,j] <- rho*X[,j-1] + (1-rho)*rnorm(n, mu, sigma)
# }
if(scaleX){
  X <- scale(X,T,T)
}
X <- cbind(1, X)   # with intercept

# beta0 <- rep(0,p)
# beta0[1] <- -55
# beta0[2:6] <- 10
# beta0[7:11] <- 1
# beta0[12:21] <- .1
beta0 = c(0,8,4,2,1,rep(0,p-5))

Xb <- X %*% beta0
####



#### Run sims
inci <- pvs <- sig_ci <- beta_nonzero <- est_inci <- matrix(NA, p-1, ne)   # fraction of times true coefficient in CI

# inci[1,] <- 1
# pvs[1,] <- 0
# sig_ci[1,] <- 1
# beta_nonzero[1,] <- 1

for(i in 1:ne){
  set.seed(i)
  eps <- rnorm(n)
  Y <- Xb + eps
  Y <- 1*(c(Y)>0)
  if(all(Y==1)){Y[length(Y)] <- 0}
  if(all(Y==0)){Y[length(Y)] <- 1}
  
  # Fit lasso choosing lambda by CV and min mean AUC, minus 1 to deal with intercept
  cv <- cv.glmnet(x=X[,-1], y=Y, family="binomial", type.measure = "auc", standardize=!scaleX)   # thresh?   
  beta <- coef(cv)   # minimum mean AUC default choice
  lambda <- cv$lambda.1se   # lambda chosen
  
  nonzeros <- which(beta[-1] != 0) 
  out <- fixedLassoInf(x=X[,-1], y=Y, beta=beta, lambda=lambda*n, family="binomial", alpha=.05, tol.beta=1e-9)
  
  beta_nonzero[nonzeros, i] <- 1
  beta_nonzero[-nonzeros, i] <- 0
  
  inci[nonzeros, i] <- 1*(out$ci[,1] < beta0[-1][nonzeros] & out$ci[,2] > beta0[-1][nonzeros])  # true coeff in CIs?
  # inci[-1,][-nonzeros, i] <- 1*(beta0[-1][-nonzeros]==0)  # true coeff estimated zero and is actually zero
  
  sig_ci[nonzeros, i] <- 1*!(out$ci[,1] < 0 & out$ci[,2] > 0)  # signif nonzero?
  # sig_ci[-nonzeros, i] <- 0  # 1*(beta0[-nonzeros]==0)  # true coeff estimated zero and is actually zero
  
  pvs[nonzeros, i] <- out$pv
  # pvs[-nonzeros, i] <- 
  
  est_inci[nonzeros, i] <- 1*(out$ci[,1] < beta[-1][nonzeros] & out$ci[,2] > beta[-1][nonzeros])
  
  
  if(i %% 100 == 0){cat(i, "; \t")}
}
####

apply(beta_nonzero,1,mean, na.rm=T)
apply(inci,1,mean, na.rm=T)



truezero <- which(beta0[-1] == 0)
empa <- mean(pvs[truezero,] < .05, na.rm=T)
ninf <- sum(beta_nonzero[truezero,])   # number of opportunities for inference

nonzeroest <- which(beta_nonzero == 1, arr.ind=T)
delta <- 1*(pvs < .05) != sig_ci
# itest <- nonzeroest[ !(nonzeroest[,1] %in% truezero), ]
disagfrac <- mean(delta[nonzeroest], na.rm=T)
ndisag <- nrow(nonzeroest)

powerci <- apply(sig_ci[-truezero,],1,mean, na.rm=T)
powerp <- apply(pvs[-truezero,],1,function(z) mean(z < .05, na.rm=T))


estin <- mean(est_inci[sig_ci == 1], na.rm=T)

outfile <- data.frame( cbind(empa, ninf, disagfrac, ndisag, estin, powerp, powerci, beta0[-1][1:length(powerp)]))


names(outfile) <- c("emp_alpha", "nalpha", "disag_frac", "ndisag",  "frac_estinci", "power_p", "power_ci", "beta0")

outdir <- file.path(writedir, paste0("sicheck_nominal_n",n,"_p",p,"_scale", as.numeric(scaleX),"_seed",seed,"_lambdaCV"))
dir.create(outdir, showWarnings=F)
write.table(inci, file=file.path(outdir, paste0("inci.txt")), row.names=F, col.names=F)
write.table(sig_ci, file=file.path(outdir, "sig_ci.txt"), row.names=F, col.names=F)
write.table(pvs, file=file.path(outdir, "pvs.txt"), row.names=F, col.names=F)
write.table(beta_nonzero, file=file.path(outdir, "beta_nonzero.txt"), row.names=F, col.names=F)
write.table(est_inci, file=file.path(outdir, "est_inci.txt"), row.names=F, col.names=F)
write.table(outfile, file=file.path(outdir, "summary.txt"), row.names=F, col.names=F)











# 
# 
# #### Run sims for centered/scaled covariates
# X <- cbind(1, scale(X[,-1], TRUE, TRUE))  # centered/scaled
# beta0 <- rep(0,p)
# beta0[1] <- -10
# beta0[2:6] <- 10
# beta0[7:11] <- 1
# beta0[12:21] <- .1
# Xb <- X %*% beta0
# inci_cs <- matrix(0, p, ne)   # fraction of times true coefficient in CI
# 
# for(i in 1:ne){
#   eps <- rlogis(n)
#   Y <- Xb + eps
#   Y <- 1*(Y>0)
#   
#   # Fit lasso choosing lambda by CV and min mean AUC, minus 1 to deal with intercept
#   cv <- cv.glmnet(x=X[,-1], y=Y, family="binomial",type.measure = "auc")   
#   beta <- coef(cv)   # minimum mean AUC default choice
#   lambda <- cv$lambda.min   # lambda chosen
#   
#   nonzeros <- which(beta[-1] != 0)
#   out <- fixedLassoInf(x=X[,-1], y=Y, beta=beta, lambda=lambda*n, family="binomial", alpha=.05, tol.beta = 1e-20)
#   
#   inci_cs[-1,][nonzeros, i] <- 1*(out$ci[,1] < beta0[-1][nonzeros] & out$ci[,2] > beta0[-1][nonzeros])  # true coeff in CIs?
#   inci_cs[-1,][-nonzeros, i] <- 1*(beta0[-1][-nonzeros]==0)  # true coeff estimated zero and is actually zero
#   
# }
# ####
# 
# apply(inci_cs,1,mean)
# outdir <- paste0("scaledX_n",n,"_p",p,"_seed",seed,"_lambdaCV")
# dir.create(outdir, showWarnings=F)
# write.table(inci_cs, file=file.path(outdir, "inci.txt"), row.names=F, col.names=F)
# 
# 
# 
# 
# 
# #### Run sims for centered/scaled covariates
# lambda <- .01
# inci_cs2 <- matrix(0, p, ne)   # fraction of times true coefficient in CI
# 
# for(i in 1:ne){
#   eps <- rnorm(n)
#   Y <- Xb + eps
#   Y <- 1*(Y>0)
#   
#   # Fit lasso choosing lambda by CV and min mean AUC, minus 1 to deal with intercept
#   # cv <- cv.glmnet(x=X[,-1], y=Y, family="binomial",type.measure = "auc")   
#   cv <- glmnet(x=X[,-1], y=Y, family="binomial")   
#   beta <- coef(cv, s=lambda, exact=TRUE)   # fixed lambda choice
#   # lambda <- cv$lambda.min   # lambda chosen
#   
#   nonzeros <- which(beta[-1] != 0)
#   out <- fixedLassoInf(x=X[,-1], y=Y, beta=beta, lambda=lambda*n, family="binomial", alpha=.05)
#   
#   inci_cs2[-1,][nonzeros, i] <- 1*(out$ci[,1] < beta0[-1][nonzeros] & out$ci[,2] > beta0[-1][nonzeros])  # true coeff in CIs?
#   inci_cs2[-1,][-nonzeros, i] <- 1*(beta0[-1][-nonzeros]==0)  # true coeff estimated zero and is actually zero
#   
#   if(i %% 100 == 0){cat(i, "; \t")}
# }
# ####
# 
# apply(inci_cs2,1,mean)
# outdir <- paste0("scaledX_n",n,"_p",p,"_seed",seed,"_lambda",format(lambda, scientific=T))
# dir.create(outdir, showWarnings=F)
# write.table(inci_cs2, file=file.path(outdir, "inci.txt"), row.names=F, col.names=F)
# 
# 
# 
# 
# 
# #### Run sims using example with code
# set.seed(43)
# n <- 100
# p <- 50
# X <- matrix(rnorm(n*p),n,p)
# # beta0 <- c(5:1,rep(0,p-5))
# beta = c(3,2,rep(0,p-2))
# Xb <- X %*% beta0
# lambda <- .8/n
# inci_cs3 <- pvs3 <- sig_ci3 <- matrix(0, p, ne)   # fraction of times true coefficient in CI
# 
# for(i in 1:ne){
#   eps <- rnorm(n)*1
#   Y <- Xb + eps
#   Y <- 1*(Y>mean(Y))
#   
#   # Fit lasso choosing lambda by CV and min mean AUC, minus 1 to deal with intercept
#   # cv <- cv.glmnet(x=X[,-1], y=Y, family="binomial",type.measure = "auc")   
#   cv <- glmnet(x=X, y=Y, standardize=FALSE, family="binomial")   
#   beta <- coef(cv, s=lambda, exact=TRUE)   # fixed lambda choice
#   # lambda <- cv$lambda.min   # lambda chosen
#   
#   nonzeros <- which(beta[-1] != 0)
#   out <- fixedLassoInf(x=X, y=Y, beta=beta, lambda=lambda*n, family="binomial") #, alpha=.05)
#   
#   inci_cs3[,][nonzeros, i] <- 1*(out$ci[,1] < beta0[nonzeros] & out$ci[,2] > beta0[nonzeros])  # true coeff in CIs?
#   inci_cs3[,][-nonzeros, i] <- 1*(beta0[-nonzeros]==0)  # true coeff estimated zero and is actually zero
#   
#   sig_ci3[,][nonzeros, i] <- 1*!(out$ci[,1] < 0 & out$ci[,2] > 0)  # signif nonzero?
#   sig_ci3[,][-nonzeros, i] <- 0  # 1*(beta0[-nonzeros]==0)  # true coeff estimated zero and is actually zero
#   
#   pvs3[,][nonzeros, i] <- out$pv
#   pvs3[,][-nonzeros, i] <- .5
#   
#   if(i %% 100 == 0){cat(i, "; \t")}
# }
# ####
# 
# apply(inci_cs3,1,mean, na.rm=T)
# apply(sig_ci3,1,mean, na.rm=T)
# apply(pvs3,1,function(z) mean(z < .05, na.rm=T))
# 
# # outdir <- paste0("scaledX_n",n,"_p",p,"_seed",seed,"_lambda",format(lambda, scientific=T))
# # dir.create(outdir, showWarnings=F)
# # write.table(inci_cs2, file=file.path(outdir, "inci.txt"), row.names=F, col.names=F)
# 
# 
# 
# 