# Plot si confidence interval investigation


rm(list=ls())
library("RColorBrewer")
library("xtable")
colors <- brewer.pal(8, "Set2")
plotdir <- "~/Dropbox/BiTEN/check_selectiveInference_1.2.2"


ns <- c(100,1000)
seed <- 43
p <- 50
truezeros <- 5:49   # hardcoded!
results <- NULL

for(n in ns){
  for(scaleX in c(T, F)){
    for(version in c("1.2.2", "1.2.4")){
      readdir <- paste0("~/Dropbox/BiTEN/check_selectiveInference_", version)
      subdir <- paste0("sicheck_nominal_n",n,"_p", p, "_scale", as.numeric(scaleX),"_seed",seed,"_lambdaCV")
      
      pvs <- read.table(file.path(readdir, subdir, "pvs.txt"))
      sig_ci <- read.table(file.path(readdir, subdir, "sig_ci.txt"))
      beta_nonzeros <- read.table(file.path(readdir, subdir, "beta_nonzero.txt"))
      nonzeroest <- which(beta_nonzeros == 1, arr.ind=T)
      nonzeroest <- nonzeroest[nonzeroest[,1] %in% truezeros, ]
      
      temp <- cbind(n, scaleX, version, read.table(file.path(readdir, subdir, "summary.txt")))
      
      temp[,4] <- mean(pvs[nonzeroest] < .05, na.rm=T)
      temp[,5] <- nrow(nonzeroest)
      temp <- cbind(temp, mean(as.matrix(sig_ci[nonzeroest]), na.rm=T), sum(sig_ci, na.rm=T))
      results <- rbind(results, temp)
    }
  }
}

names(results) <- c("n", "scaleX", "version", "emp_alpha_pv", "nalpha", "disag_frac", "ndisag",  "frac_estinci", "power_p", "power_ci", "beta0", "emp_alpha_ci", "nsig")
results <- results[, c(1:4, 12, 5:11, 13)]


for(n in ns){
  for(scaleX in c(T, F)){
    temp <- results[results$n == n & results$scaleX == scaleX,]
    temp <- temp[order(temp$beta0),]
    
    pdf(file.path(plotdir, paste0("power_n", n, "_scaleX", as.numeric(scaleX),  ".pdf")), height=4,width=4.5)
    par(mar=c(3,3,.5,.5), cex.axis=.8, cex.lab=.8, mgp=c(1.7,.5,0))
    plot(NA, NA, xlab="true coefficient", ylab="power", xaxt="n", ylim=range(temp[, c("power_p", "power_ci")]), xlim=c(1, length(unique(temp$beta0))))
    lines(1:length(unique(temp$beta0)), temp$power_ci[temp$version == "1.2.2"], type="o", lty=1, lwd=1.5, pch=1, col=colors[1])
    lines(1:length(unique(temp$beta0)), temp$power_p[temp$version == "1.2.2"], type="o", lty=2, lwd=1.5, pch=2, col=colors[1])
    
    jitter <- .0 #rnorm(1, 0, .05)
    lines(1:length(unique(temp$beta0)) + jitter, temp$power_ci[temp$version == "1.2.4"], type="o", lty=1, lwd=1.5, pch=3, col=colors[2])
    lines(1:length(unique(temp$beta0)) + jitter, temp$power_p[temp$version == "1.2.4"], type="o", lty=2, lwd=1.5, pch=4, col=colors[2])
    
    axis(1, at=1:length(unique(temp$beta0)), labels = sort(unique(temp$beta0)))
    
    if(n == ns[1] & scaleX == T){
      legend("topleft", c("CI, 1.2.2", "pval, 1.2.2", "CI, 1.2.4", "pval, 1.2.4"), lwd=1.5, lty=c(1,2,1,2), col=colors[c(1,1,2,2)], pch=1:4, cex=.8, bty="n")
    }
    dev.off()
    
  }
}


sink(file.path(plotdir, "comparison_table.txt"))
print( xtable( unique(results[, c("n", "scaleX", "version", "emp_alpha_pv", "emp_alpha_ci", "nalpha", "disag_frac", "ndisag",  "frac_estinci", "nsig")]), digits=4 ))
sink()

